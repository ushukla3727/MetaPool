﻿using UnityEngine;
using System.Collections;

public class AddAvatars : MonoBehaviour {


	public Sprite[] sprites;
	public GameObject prefab;
	// Use this for initialization
	void Start () {
		
		

	}

	
	// Update is called once per frame
	void Update () {
	
	}


}
