﻿using UnityEngine;
using System.Collections;
using Facebook.Unity;
using System.Collections.Generic;
using Facebook;
using Facebook.MiniJSON;
using UnityEngine.UI;
using AssemblyCSharp;
using UnityEngine.Networking;
using SimpleJSON;

public class FacebookManager : MonoBehaviour
{

    private PlayFabManager playFabManager;
    //public ClaimCoinManager ccm;
    public TestScript testscript;
    public string name;
    public Sprite sprite;
    private GameObject FbLoginButton;
    private bool LoggedIn = false;
    private FacebookFriendsMenu facebookFriendsMenu;
    private bool alreadyGotFriends = false;
    public GameObject splashCanvas;
    public GameObject loginCanvas;
    public GameObject fbButton;
    public GameObject matchPlayersCanvas;
    public GameObject menuCanvas;
    public GameObject gameTitle;
    public GameObject idLoginDialog;
    public GameObject idRegisterDialog;
    public GameObject forgetPasswordDialog;
    //GameObject cliamCoin = GameObject.Find("Equipment_Popup_AddSlot");


    public InputField loginEmail;
    public InputField loginPassword;
    public GameObject loginInvalidEmailorPassword;

    public InputField regiterEmail;
    public InputField registerPassword;
    public InputField registerNickname;
    public GameObject registerInvalidInput;

    public InputField resetPasswordEmail;
    public GameObject resetPasswordInformationText;


    void Start()
    {
        Debug.Log("FBManager start");
        GameManager.Instance.facebookManager = this;

        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        FbLoginButton = GameObject.Find("FbLoginButton");

        facebookFriendsMenu = GameManager.Instance.facebookFriendsMenu; //.GetComponent <FacebookFriendsMenu> ();
    }

    // Awake function from Unity's MonoBehavior
    void Awake()
    {
        Debug.Log("FBManager awake");
        GameManager.Instance.facebookManager = this;
        DontDestroyOnLoad(transform.gameObject);
        playFabManager = GameObject.Find("PlayFabManager").GetComponent<PlayFabManager>();
        if (!GameManager.Instance.logged)
        {

    		if (!FB.IsInitialized) {
    			// Initialize the Facebook SDK
    			FB.Init(InitCallback, OnHideUnity);
    		} else {
    			// Already initialized, signal an app activation App Event
    			FB.ActivateApp();
                initSession();
    		}
            initSession();

            GameManager.Instance.logged = true;
        }
    }

    private void InitCallback()
    {
        if (FB.IsInitialized)
        {
            // Signal an app activation App Event
            FB.ActivateApp();
            // Continue with Facebook SDK
            // ...

            //			if (PlayerPrefs.GetString ("LoggedType").Equals ("Facebook")) {
            //				Debug.Log ("Already logged to facebook!!!!");
            initSession();
            //			}

        }
        else
        {
            Debug.Log("Failed to Initialize the Facebook SDK");
        }
    }

    private void OnHideUnity(bool isGameShown)
    {
        if (!isGameShown)
        {
            // Pause the game - we will need to hide
            Time.timeScale = 0;
        }
        else
        {
            // Resume the game - we're getting focus again
            Time.timeScale = 2;
        }
    }

    public void startRandomGame()
    {
        //		menuCanvas.SetActive (false);
        //		gameTitle.SetActive (false);

        GameManager.Instance.matchPlayerObject.GetComponent<SetMyData>().MatchPlayer();
        GameManager.Instance.matchPlayerObject.GetComponent<SetMyData>().setBackButton(true);
        //		matchPlayersCanvas.GetComponent <SetMyData> ().MatchPlayer ();
        //		matchPlayersCanvas.GetComponent <SetMyData> ().setBackButton (true);
        playFabManager.JoinRoomAndStartGame();
    }


    public void FBLogin()
    {
        if (!LoggedIn)
        {
            var perms = new List<string>() { "public_profile", "email", "user_friends" };
            FB.LogInWithReadPermissions(perms, AuthCallback);
        }
        else
        {
            playFabManager.JoinRoomAndStartGame();
        }

    }



    public void GuestLogin()
    {
        if (!LoggedIn)
        {
            playFabManager.Login();
        }
    }

    public void showRegisterDialog()
    {
        idLoginDialog.SetActive(false);
        idRegisterDialog.SetActive(true);
    }

    public void CloseLoginDialog()
    {
        loginInvalidEmailorPassword.SetActive(false);
        loginEmail.text = "";
        loginPassword.text = "";

        loginCanvas.SetActive(true);
        idLoginDialog.SetActive(false);
    }

    public void CloseRegisterDialog()
    {
        regiterEmail.text = "";
        registerPassword.text = "";
        registerNickname.text = "";
        registerInvalidInput.SetActive(false);
        loginCanvas.SetActive(true);
        idRegisterDialog.SetActive(false);
    }

    public void CloseForgetPasswordDialog()
    {
        resetPasswordEmail.text = "";
        resetPasswordInformationText.SetActive(false);
        forgetPasswordDialog.SetActive(false);
        loginCanvas.SetActive(true);
    }

    public void showForgetPasswordDialog()
    {
        forgetPasswordDialog.SetActive(true);
        idLoginDialog.SetActive(false);



    }

    public void IDLoginButtonPressed()
    {
        loginCanvas.SetActive(false);
        idLoginDialog.SetActive(true);
    }

    public void IDLogin()
    {
        if (!LoggedIn)
        {
            var perms = new List<string>() { "public_profile", "email", "user_friends" };
            FB.LogInWithReadPermissions(perms, AuthCallback);
        }
    }

    private void AuthCallback(ILoginResult result)
    {
        if (FB.IsLoggedIn)
        {
            // AccessToken class will have session details
            var aToken = Facebook.Unity.AccessToken.CurrentAccessToken;
            // Print current access token's User ID

            GameManager.Instance.facebookIDMy = aToken.UserId;
            // Print current access token's granted permissions
            Debug.Log(aToken.ToJson());
            foreach (string perm in aToken.Permissions)
            {
                Debug.Log(perm);
            }
            FB.API("/me?fields=id,name,email", HttpMethod.GET, GetFacebookInfo, new Dictionary<string, string>() { });
            //			getFacebookInvitableFriends ();
            //			getFacebookFriends ();
            //			callApiToGetName ();
            //			getMyProfilePicture (GameManager.Instance.facebookIDMy);
            //
            //
            //			LoggedIn = true;
            //
            //			GameObject.Find ("FbLoginButtonText").GetComponent <Text>().text = "Play";

            PlayerPrefs.SetString("LoggedType", "Facebook");
            PlayerPrefs.Save();

            loginCanvas.SetActive(false);
            splashCanvas.SetActive(true);


            initSession();



        }
        else
        {
            Debug.Log("User cancelled login");
        }
    }

    private void initSession()
    {
        Debug.Log("FbManager init session");

        string logType = PlayerPrefs.GetString("LoggedType");
        if (logType.Equals("Facebook"))
        {
            GameManager.Instance.facebookIDMy = Facebook.Unity.AccessToken.CurrentAccessToken.UserId;
            callApiToGetName();
            getMyProfilePicture(GameManager.Instance.facebookIDMy);


            LoggedIn = true;


        }
        else if (logType.Equals("Guest"))
        {
            playFabManager.Login();
        }
        else if (logType.Equals("EmailAccount"))
        {
            playFabManager.LoginWithEmailAccount();
        }

    }

    
    private void callApiToGetName()
    {
        FB.API("me?fields=first_name,email", Facebook.Unity.HttpMethod.GET, APICallbackName);
        //FB.API("/me?fields=id,name,email", HttpMethod.GET, GetFacebookInfo, new Dictionary<string, string>() { });
    }

    public void GetFacebookInfo(IResult result)
    {
        if (result.Error == null)
        {
            Debug.Log("ID = "+result.ResultDictionary["id"].ToString());
            Debug.Log("NAME = " + result.ResultDictionary["name"].ToString());
            Debug.Log("EMAIL = " + result.ResultDictionary["email"].ToString());
            StartCoroutine(Signup(result.ResultDictionary["name"].ToString(), result.ResultDictionary["email"].ToString()));
            Debug.Log("h1");
            //ccm.Show();
            testscript.OpenConfirmationWindow("Claim open game object");
            Debug.Log("active window");
        }
        else
        {
            Debug.Log(result.Error);
        }
    }

    void APICallbackName(IResult response)
    {
        GameManager.Instance.nameMy = response.ResultDictionary["first_name"].ToString();
        Debug.Log("My name " + GameManager.Instance.nameMy);
    }

    IEnumerator Signup(string name, string email)
    {
        Debug.Log("Hello name email save");
        WWWForm form = new WWWForm();
        form.AddField("name", name);
        form.AddField("email", email);
        using (UnityWebRequest www = UnityWebRequest.Post("https://www.vibhoragrawal.in/8ballpool/api/signup", form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                Debug.Log(www.downloadHandler.text);
                JSONNode itemsData = JSON.Parse(www.downloadHandler.text);
                Debug.Log(itemsData["data"]);
                PlayerPrefs.SetInt("id", itemsData["data"]["id"]);
                PlayerPrefs.SetInt("is_cliamed", itemsData["data"]["is_claimed"]);
                PlayerPrefs.Save();
                Debug.Log(itemsData["data"]["is_claimed"]);
                if(itemsData["data"]["is_claimed"]=="0")
                {
                    Debug.Log("Not Claimed");
                }
                Debug.Log("email saved!");
            }
        }
    }
    public void getMyProfilePicture(string userID)
    {

        //FB.API("/" + userID + "/picture?type=square&height=92&width=92", Facebook.Unity.HttpMethod.GET, delegate(IGraphResult result) {
        FB.API("/me?fields=picture.width(200).height(200)", Facebook.Unity.HttpMethod.GET, delegate (IGraphResult result) {
            if (result.Error == null)
            {

                // use texture

                Dictionary<string, object> reqResult = Json.Deserialize(result.RawResult) as Dictionary<string, object>;

                if (reqResult == null) Debug.Log("JEST NULL"); else Debug.Log("nie null");


                GameManager.Instance.avatarMyUrl = ((reqResult["picture"] as Dictionary<string, object>)["data"] as Dictionary<string, object>)["url"] as string;
                Debug.Log("My avatar " + GameManager.Instance.avatarMyUrl);

                StartCoroutine(loadImageMy(GameManager.Instance.avatarMyUrl));

                //GameManager.Instance.avatarMy = Sprite.Create(result.Texture, new Rect(0, 0, result.Texture.width, result.Texture.height), new Vector2(0.5f, 0.5f), 32);

                playFabManager.LoginWithFacebook();
            }
            else
            {
                Debug.Log("Error retreiving image: " + result.Error);
            }
        });
    }

    public IEnumerator loadImageMy(string url)
    {
        // Load avatar image

        // Start a download of the given URL
        WWW www = new WWW(url);

        // Wait for download to complete
        yield return www;


        GameManager.Instance.avatarMy = Sprite.Create(www.texture, new Rect(0, 0, www.texture.width, www.texture.height), new Vector2(0.5f, 0.5f), 32);

    }

    public void getOpponentProfilePicture(string userID)
    {

        FB.API("/" + userID + "/picture?type=square&height=92&width=92", Facebook.Unity.HttpMethod.GET, delegate (IGraphResult result) {
            if (result.Texture != null)
            {
                // use texture

                GameManager.Instance.avatarMy = Sprite.Create(result.Texture, new Rect(0, 0, result.Texture.width, result.Texture.height), new Vector2(0.5f, 0.5f), 32);

                playFabManager.LoginWithFacebook();
            }
        });
    }





    public void getFacebookInvitableFriends()
    {
        if (alreadyGotFriends)
        {
            facebookFriendsMenu.showFriends();
        }
        else
        {
            //&fields=picture.width(100).height(100)
            FB.API("/me/invitable_friends?limit=5000&fields=id,name,picture.width(100).height(100)", Facebook.Unity.HttpMethod.GET, delegate (IGraphResult result) {

                if (result.Error == null)
                {
                    List<string> friendsNames = new List<string>();
                    List<string> friendsIDs = new List<string>();
                    List<string> friendsAvatars = new List<string>();
                    //Grab all requests in the form of a dictionary. 

                    Dictionary<string, object> reqResult = Json.Deserialize(result.RawResult) as Dictionary<string, object>;
                    //Grab 'data' and put it in a list of objects. 


                    List<object> newObj = reqResult["data"] as List<object>;
                    //For every item in newObj is a separate request, so iterate on each of them separately. 


                    Debug.Log("Friends Count: " + newObj.Count);
                    for (int xx = 0; xx < newObj.Count; xx++)
                    {
                        Dictionary<string, object> reqConvert = newObj[xx] as Dictionary<string, object>;

                        string name = reqConvert["name"] as string;
                        string id = reqConvert["id"] as string;

                        //friendsNames.Add (name);
                        //friendsIDs.Add (id);

                        Dictionary<string, object> avatarDict = reqConvert["picture"] as Dictionary<string, object>;
                        avatarDict = avatarDict["data"] as Dictionary<string, object>;

                        string avatarUrl = avatarDict["url"] as string;
                        //friendsAvatars.Add (avatarUrl);
                        //Debug.Log("URL: " + avatarUrl);
                        GameManager.Instance.facebookFriendsMenu.AddFacebookFriend(name, id, avatarUrl);
                    }

                    //					alreadyGotFriends = true;
                    //					facebookFriendsMenu.showFriends (friendsNames, friendsIDs, friendsAvatars);



                }
                else
                {
                    Debug.Log("Something went wrong. " + result.Error + "  " + result.ToString());
                }

            });

        }
    }


    public void destroy()
    {
        if (this.gameObject != null)
            DestroyImmediate(this.gameObject);
    }

    public void showLoadingCanvas()
    {
        loginCanvas.SetActive(false);
        splashCanvas.SetActive(true);
    }



}
