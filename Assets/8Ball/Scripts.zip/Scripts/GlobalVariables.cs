using System;

namespace AssemblyCSharp {
    public static class GlobalVariables {
        // How much coins player should get if he invite friend

        // How many coins user have after register


    }
}

